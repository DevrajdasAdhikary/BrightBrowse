document.getElementById('backButton').addEventListener('click', () => {
    window.location.href = 'main.html';
});

document.addEventListener('DOMContentLoaded', function() {
    fetchAndPopulatePatterns();
});

async function fetchAndPopulatePatterns() {
    let patterns = localStorage.getItem('darkPatterns');
    let savedSettings = localStorage.getItem('userSettings');
    const accessToken = localStorage.getItem('accessToken');

    // Fetch the dark patterns list if not already stored
    if (!patterns) {
        try {
            const response = await fetch('http://localhost:8000/scan/dark-pattern-types/', {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${accessToken}`,
                },
            });
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            const jsonData = await response.json();
            patterns = JSON.stringify(jsonData);
            localStorage.setItem('darkPatterns', patterns);
        } catch (error) {
            console.error('Failed to fetch dark patterns:', error);
            return;
        }
    }

    // Fetch the saved settings if not already stored
    if (!savedSettings) {
        try {
            const response = await fetch('http://localhost:8000/user/settings/', {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${accessToken}`,
                },
            });
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            let temp = await response.json();
            temp = { ...temp.user_settings, whitelist_urls: temp.whitelist_urls }
            savedSettings = JSON.stringify(temp);
            localStorage.setItem('userSettings', savedSettings);
            localStorage.setItem('auto_scan', temp.auto_scan);
        } catch (error) {
            console.error('Failed to fetch saved settings:', error);
            return;
        }
    }

    // Now parse the JSON strings after ensuring they exist
    savedSettings = JSON.parse(savedSettings);
    patterns = JSON.parse(patterns);
    populateSettings(savedSettings, patterns);
}

function populateSettings(settings, patterns) {
    console.log(settings, patterns);

    if (settings) {
        // Set the sensitivity level
        const severityToValue = { 'low': '1', 'high': '2' };
        document.getElementById('sensitivityLevel').value = severityToValue[settings.severity || 'low'];
        document.getElementById('sensitivityLevel').dispatchEvent(new Event('input'));

        // Mark selected patterns
        const allowedPatterns = settings.allowed_pattern ? settings.allowed_pattern.split('|') : [];
        const fieldset = document.getElementById('allowedPatternList');

        // Ensure patterns is an array
        if (!Array.isArray(patterns)) {
            console.error('Expected patterns to be an array, but received:', patterns);
            patterns = [];
        }
        console.log(allowedPatterns)

        patterns.forEach(pattern => {
            const label = document.createElement('label');
            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.name = 'patterns';
            checkbox.value = pattern.title;
            checkbox.checked = allowedPatterns.includes(pattern.title);
            label.appendChild(checkbox);
            label.append(` ${pattern.title}`);
            fieldset.appendChild(label);
        });

        // Set automatic scanning
        document.getElementById('automaticScanning').checked = settings.auto_scan || false;

        // Populate whitelist URLs
        if (settings.whitelist_urls?.length) {
            const whitelistEntries = document.getElementById('whitelistEntries');
            whitelistEntries.innerHTML = '';
            settings.whitelist_urls.forEach(url => {
                const newEntry = document.createElement('div');
                newEntry.innerHTML = `
                    <input type="text" placeholder="https://example.com" value="${url}" aria-label="Website URL">
                    <button class="removeWebsite" aria-label="Remove Website">X</button>
                `;
                whitelistEntries.appendChild(newEntry);
            });
        }
    }
}

document.getElementById('sensitivityLevel').addEventListener('input', function() {
    const value = this.value;
    document.getElementById('lowLabel').style.display = 'none';
    document.getElementById('highLabel').style.display = 'none';

    if (value === '2') {
        document.getElementById('highLabel').style.display = 'inline';
    } else {
        document.getElementById('lowLabel').style.display = 'inline';
    }
});

document.getElementById('addWebsite').addEventListener('click', () => {
    const whitelistEntries = document.getElementById('whitelistEntries');
    const newEntry = document.createElement('div');
    newEntry.innerHTML = `
        <input type="text" placeholder="https://example.com" aria-label="Website URL">
        <button class="removeWebsite" aria-label="Remove Website">X</button>
    `;
    whitelistEntries.appendChild(newEntry);
});

document.getElementById('whitelistEntries').addEventListener('click', (event) => {
    if (event.target.className === 'removeWebsite') {
        event.target.parentElement.remove();
    }
});

document.getElementById('saveButton').addEventListener('click', () => {
    const sensitivity = document.getElementById('sensitivityLevel').value;
    const severity = { '1': 'low', '2': 'high' }[sensitivity];
    const allowed_pattern = [...document.querySelectorAll('input[name="patterns"]:checked')].map(el => el.value).join('|');
    const auto_scan = document.getElementById('automaticScanning').checked;
    const whitelist_urls = [...document.querySelectorAll('#whitelistEntries input[type="text"]')].map(el => el.value);

    saveSettings({ severity, allowed_pattern, auto_scan, whitelist_urls });
});

async function saveSettings(settings) {
    try {
        const accessToken = localStorage.getItem('accessToken');
        const response = await fetch('http://localhost:8000/user/settings/update/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${accessToken}`,
            },
            body: JSON.stringify(settings),
        });

        if (!response.ok) {
            throw new Error('Network response was not ok');
        }

        localStorage.setItem('userSettings', JSON.stringify(settings));
        localStorage.setItem('auto_scan', settings.auto_scan);
        console.log('Settings saved successfully.');
        window.location.href = 'main.html';
    } catch (error) {
        console.error('Update User Settings Error:', error);
    }
}
