document.getElementById('backButton').addEventListener('click', () => {
    window.location.href = 'main.html';
});

document.addEventListener('DOMContentLoaded', function() {
    console.log('Loaded document')
    initializeForm();
});

async function initializeForm(){
    let patterns = localStorage.getItem('darkPatterns');
    const accessToken = localStorage.getItem('accessToken');

    // Fetch the dark patterns list if not already stored
    if (!patterns) {
        try {
            const response = await fetch('http://localhost:8000/scan/dark-pattern-types/', {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${accessToken}`,
                },
            });
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            const jsonData = await response.json();
            patterns = JSON.stringify(jsonData);
            localStorage.setItem('darkPatterns', patterns);
        } catch (error) {
            console.error('Failed to fetch dark patterns:', error);
            return;
        }
    }

    patterns = await JSON.parse(patterns)
    const darkPatternSelect = document.getElementById('darkPatternCategory');
    patterns.forEach((pattern) => {
        const option = document.createElement('option');
        option.value = pattern.id;
        option.text = pattern.title;
        darkPatternSelect.appendChild(option);
    });
}

document.getElementById('submitReport').addEventListener('click', (event) => {
    event.preventDefault();
    const websiteUrl = document.getElementById('websiteUrl').value;
    const darkPatternCategory = document.getElementById('darkPatternCategory').value;
    const patternTopic = document.getElementById('patternTopic').value;
    const patternDescription = document.getElementById('patternDescription').value;
    const solution = document.getElementById('solution').value;
    const accessToken = localStorage.getItem('accessToken');

    if (!websiteUrl || !darkPatternCategory || !patternTopic || !patternDescription || !solution) {
        alert('Please fill out all fields.');
        return;
    }

    // Submit the dark pattern report
    const data = {
        url: websiteUrl,
        dark_pattern_type: darkPatternCategory,
        topic: patternTopic,
        description: patternDescription,
        solution: solution,
    };
    fetch('http://localhost:8000/scan/report/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`,
        },
        body: JSON.stringify(data),
    })
    .then(response => {
        if (response.ok) {
            window.location.href = 'main.html';
        } else {
            throw new Error('Failed to submit report');
        }
    })
    .catch(error => {
        console.error(error);
    });
});