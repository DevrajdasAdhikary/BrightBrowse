import pickle
import re
import string
import os
from nltk.stem import WordNetLemmatizer
import nltk
nltk.download('wordnet')
from PIL import Image
import requests
from io import BytesIO
from inference_sdk import InferenceHTTPClient

class DarkPatternDetector:
    def __init__(self):
        self.vectorizer = self._load_pickle('scan/utils/models/fitted_count_vectorizer.pkl')
        self.model = self._load_pickle('scan/utils/models/best_logistic_model.pkl')
        self.label_mapping = {
            0: "No Dark Pattern",
            1: "Urgency",
            2: "Scarcity",
            3: "Social Proof",
            4: "Misdirection",
            5: "Persuasive Pattern"
        }
        self.lemmatizer = WordNetLemmatizer()
        self.roboflow_client = InferenceHTTPClient(
            api_url="https://detect.roboflow.com",
            api_key= os.getenv("ROBO_API_KEY")
        )

    def _load_pickle(self, filepath):
        with open(filepath, 'rb') as file:
            return pickle.load(file)

    def _remove_punctuation(self, text):
        return "".join([c for c in text if c not in string.punctuation])

    def _lower_text(self, text):
        return text.lower()

    def _remove_emoji(self, text):
        emoji_pattern = re.compile("["
                                   "\U0001F600-\U0001F64F"  # emoticons
                                   "\U0001F300-\U0001F5FF"  # symbols & pictographs
                                   "\U0001F680-\U0001F6FF"  # transport & map symbols
                                   "\U0001F1E0-\U0001F1FF"  # flags (iOS)
                                   "\U00002702-\U000027B0"
                                   "\U000024C2-\U0001F251"
                                   "]+", flags=re.UNICODE)
        return emoji_pattern.sub(r"", text)

    def _convert_num_to_label(self, text):
        num_pattern = re.compile("[0-9]+")
        return num_pattern.sub(r"number", text)

    def _lemmatize_text(self, text):
        text = text.lower()
        return " ".join(self.lemmatizer.lemmatize(word) for word in text.split())

    def _preprocess_text_for_prediction(self, text):
        text = self._remove_punctuation(text)
        text = self._lower_text(text)
        text = self._remove_emoji(text)
        text = self._convert_num_to_label(text)
        text = self._lemmatize_text(text)
        return text

    def predict_label_for_text(self, text: str) -> dict:
        preprocessed_text = self._preprocess_text_for_prediction(text)
        text_transformed = self.vectorizer.transform([preprocessed_text])
        label_prediction = self.model.predict(text_transformed)
        return {
            'text': text,
            'dark_pattern': self.label_mapping[label_prediction[0]]
        }
    
    def analyze_image_with_model(self, image, model_id, dark_pattern_name):
        """
        Analyze a single image using the specified model and return predictions.

        Args:
        - image: The image to be analyzed.
        - model_id (str): The ID of the model to be used for inference.
        - dark_pattern_name (str): The name of the dark pattern type associated with the model.

        Returns:
        - list of dict: Contains predictions with bounding box and confidence information.
        """
        results = []
        result = self.roboflow_client.infer(image, model_id=model_id)

        for prediction in result.get('predictions', []):
            results.append({
                'class': prediction['class'],  # Dark pattern class
                'confidence': prediction['confidence'],  # Confidence of the prediction
                'bounding_box': {
                    'x': prediction['x'],
                    'y': prediction['y'],
                    'width': prediction['width'],
                    'height': prediction['height']
                },
                'dark_pattern': dark_pattern_name
            })

        return results

detector = DarkPatternDetector()

def find_dark_patterns(extracted_texts):
    results = []
    for text in extracted_texts:
        try:
            result = detector.predict_label_for_text(text)
            if(result['dark_pattern'] != "No Dark Pattern"):
                results.append(result)
        except Exception as e:
            print(f"Error during pattern detection for text '{text}': {e}")
    return results

def process_image_screenshot(all_images):
        """
        Process a list of images using their URLs, classify them as dark patterns based on model predictions,
        and store the image URL in the `text` field.

        Args:
        - all_images (list): List of dictionaries containing image attributes and image URL.

        Returns:
        - list of dict: Contains `text` (image URL) and `dark_pattern` (identified dark pattern type).
        """
        # Define the models and their descriptions to be used
        models = [
            {"model_id": "confirm-shaming-tlnee/1", "model_name": "Confirm Shaming"},
            {"model_id": "interface-interference/1", "model_name": "Interface Interference"},
            {"model_id": "nagging/2", "model_name": "Nagging"},
            {"model_id": "disguised-add/1", "model_name": "Disguised Add"}
        ]

        final_results = []  # List to store final results

        for image_info in all_images:
            image_url = image_info.get('image_url')  # Extract the image URL
            text = image_url  # Use the image URL as the identifier for the `text` field

            try:
                # Fetch the image from the URL
                response = requests.get(image_url)
                response.raise_for_status()
                image = Image.open(BytesIO(response.content))  # Load the image
                if image.mode != "RGB":
                    image = image.convert("RGB")  # Convert to RGB if not already

                highest_confidence = 0
                detected_dark_pattern = None

                # Loop through each model and analyze the image
                for model in models:
                    results = detector.analyze_image_with_model(image, model["model_id"], model["model_name"])

                    for result in results:
                        if result['confidence'] > highest_confidence:
                            highest_confidence = result['confidence']
                            detected_dark_pattern = result['dark_pattern']

                # If a dark pattern was detected, add it to the final results
                if detected_dark_pattern:
                    final_results.append({
                        'text': text,
                        'dark_pattern': detected_dark_pattern
                    })

            except Exception as e:
                print(f"Error processing image from URL {image_url}: {e}")

        return final_results
