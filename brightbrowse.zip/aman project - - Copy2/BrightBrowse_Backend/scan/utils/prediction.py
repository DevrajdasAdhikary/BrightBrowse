from huggingface_hub import InferenceClient
import json
import os
import requests

# Assuming 'client' is initialized with an API key
client = InferenceClient(api_key=os.getenv("OPENSOURCE_API_KEY"))

def get_solutions(input_data, patterns):
    if not isinstance(input_data, list) or not all(isinstance(item, dict) for item in input_data):
        raise ValueError("Invalid input: Input data must be a list of dictionaries.")
    
    patterns_str = ""
    for pattern, sub_types in patterns.items():
        patterns_str += f"{pattern}: {', '.join(sub_types)}\n"
    
    results = []
    try:
        for item in input_data:
            # Prompt for identifying the sub dark pattern
            identify_prompt = f"Based on the major dark pattern type '{item['dark_pattern']}', identify the specific sub-type from the list of Dark Patterns and their Sub-Types:\n" + patterns_str + "\n\nItems:\n"
            identify_messages = [{"role": "user", "content": identify_prompt}]
            
            stream_identify = client.chat.completions.create(
                model=os.getenv("OPENSOURCE_MODEL"),
                messages=identify_messages, 
                max_tokens=64,
                stream=True
            )

            sub_dark_pattern = ""
            for response_chunk in stream_identify:
                sub_dark_pattern += response_chunk['choices'][0]['delta'].get('content', '')
                if 'delta' not in response_chunk['choices'][0]:
                    break
            
            sub_dark_pattern = sub_dark_pattern.strip()
            unwanted_suffix = "User"
            if sub_dark_pattern.endswith(unwanted_suffix):
                sub_dark_pattern = sub_dark_pattern[:-len(unwanted_suffix)].strip()

            # Prompt for generating the solution
            solution_prompt = f"Generate a brief, very generic, and actionable suggestion in normal language that customers can apply to avoid being misled by the dark pattern type '{item['dark_pattern']}'."
            solution_messages = [{"role": "user", "content": solution_prompt}]
            
            stream_solution = client.chat.completions.create(
                model= os.getenv("OPENSOURCE_MODEL"),
                messages=solution_messages, 
                max_tokens=128,
                stream=True
            )

            solution = ""
            for response_chunk in stream_solution:
                solution += response_chunk['choices'][0]['delta'].get('content', '')
                if 'delta' not in response_chunk['choices'][0]:
                    break
            
            solution = solution.strip()
            if solution.endswith(unwanted_suffix):
                solution = solution[:-len(unwanted_suffix)].strip()

            results.append({
                "text": item['text'],
                "dark_pattern": item['dark_pattern'],
                "sub_dark_pattern": sub_dark_pattern,
                "solution": solution
            })

    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        results = []
        for item in input_data:
            updated_item = item.copy()
            updated_item["sub_dark_pattern"] = "No specific sub-type identified"
            updated_item["solution"] = "Always verify the details through multiple reliable sources. If needed, consult authoritative sources or verified experts to ensure accurate and reliable information."
            results.append(updated_item)

    return results