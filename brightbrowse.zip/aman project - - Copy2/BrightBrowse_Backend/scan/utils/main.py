from .extraction import extract_function, final_image_extraction
from .scan import find_dark_patterns, process_image_screenshot
from .prediction import get_solutions

def main(url, severity, content, allowed_pattern, patterns):
    try:
        content_to_scan = '' if severity != 'high' else content
        extracted_texts = extract_function(url, content_to_scan)
        if not isinstance(extracted_texts, list):
            raise ValueError("Extraction did not return a valid list.")
        
        detected_patterns = find_dark_patterns(extracted_texts)
        
        
        screenshot = final_image_extraction(url)
        img_pattern = process_image_screenshot(screenshot)
        allowed_patterns_list = allowed_pattern.split('|')
        combined_patterns = detected_patterns + img_pattern
        filtered_combined_patterns = [
            pattern for pattern in combined_patterns 
            if pattern['dark_pattern'] in allowed_patterns_list
        ]

        solutions = get_solutions(filtered_combined_patterns, patterns)

        return solutions
    except Exception as e:
        print(f"Error occurred in main: {e}")
        return []
