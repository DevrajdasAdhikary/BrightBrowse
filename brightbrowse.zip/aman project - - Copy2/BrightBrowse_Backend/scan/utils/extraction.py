import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin
import random
import time

# List of user agents to rotate
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1 Safari/605.1.15",
    "Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko",
]

def extract_text_from_webpage(url):
    user_agent = random.choice(USER_AGENTS)
    headers = {
        'User-Agent': user_agent,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
    }
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        soup = BeautifulSoup(response.content, 'html.parser')
        texts = soup.stripped_strings
        content_array = [text for text in texts]
        return content_array, None
    except requests.RequestException as e:
        return [], str(e)
    except Exception as e:
        return [], str(e)

def extract_text_from_webpage_content(input_content):
    delimiter = "<bbext>"
    try:
        if not isinstance(input_content, str):
            return [], "Invalid input: Input content must be a string."
        split_contents = input_content.split(delimiter)
        return split_contents, None
    except Exception as e:
        return [], str(e)


def extract_function(url, content):
    web_texts, web_error = extract_text_from_webpage(url)
    content_texts, content_error = extract_text_from_webpage_content(content)

    # Combine and remove duplicates
    combined_texts = list(set(web_texts + content_texts))

    # Handle errors
    if web_error:
        raise ValueError(f"Webpage error: {web_error}")
    if content_error:
        raise ValueError(f"Content error: {content_error}")

    return combined_texts

def extract_images_with_retry(url, retries=3):
    """
    Scrape images from a webpage with retries for transient failures like 503 errors.
    This function is adaptable for both general websites and Amazon/other e-commerce sites.
    
    Args:
    - url (str): Webpage URL to scrape images from.
    - retries (int): Number of retries on failure.
    
    Returns:
    - list of dict: Contains image attributes and URLs.
    """
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/91.0.4472.124 Safari/537.36"
        ),
        "Accept-Language": "en-US,en;q=0.9",
        "Accept-Encoding": "gzip, deflate, br",
        "Referer": "https://www.google.com/"
    }

    while retries > 0:
        try:
            response = requests.get(url, headers=headers)
            if response.status_code == 503:
                raise Exception("503 Error")
            
            if response.status_code != 200:
                raise Exception(f"Failed to fetch webpage: {response.status_code}")
            
            soup = BeautifulSoup(response.content, 'html.parser')
            base_url = url

            # Collect image elements
            results = []
            for img in soup.find_all('img'):
                # Extract image URLs
                img_url = (
                    img.get('data-src') or
                    img.get('data-srcset') or
                    img.get('srcset') or
                    img.get('src')
                )
                if not img_url:
                    continue
                
                # Convert relative URLs to absolute
                img_absolute_url = urljoin(base_url, img_url)

                # Append image metadata
                results.append({
                    "attributes": {
                        "id": img.get('id', ''),
                        "class": img.get('class', []),
                        "alt": img.get('alt', ''),
                        "tag": "img"
                    },
                    "image_url": img_absolute_url
                })
            return results

        except Exception as e:
            print(f"Error: {e}. Retrying in 5 seconds...")
            retries -= 1
            time.sleep(5)
    
    print("All retries failed.")
    return []

def extract_images_from_webpage(url):
    """
    Extracts all image elements from a webpage and returns a dictionary containing:
    - Element attributes for potential highlighting (like id, class, or tag name)
    - URL of the image (absolute path)
    
    Args:
    - url (str): The URL of the webpage to scrape.

    Returns:
    - list of dict: Each dictionary contains:
        - "attributes": Metadata about the element (id, class, alt, tag type)
        - "image_url": Absolute URL of the image
    """
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
    }
    
    # Fetch the webpage
    response = requests.get(url, headers=headers)
    if response.status_code != 200:
        raise Exception(f"Failed to fetch webpage: {response.status_code}")
    
    # Parse the webpage content
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # Base URL for resolving relative paths
    base_url = url

    # Initialize the results list
    results = []

    # Extract all <img> elements
    for img in soup.find_all('img'):
        # Handle src and srcset
        img_url = img.get('src', '')
        if 'srcset' in img.attrs:
            # Use the first URL in srcset if available
            img_url = img['srcset'].split(',')[0].strip().split(' ')[0]
        
        img_absolute_url = urljoin(base_url, img_url)
        
        # Append image data to the results
        results.append({
            "attributes": {
                "id": img.get('id', ''),
                "class": img.get('class', []),
                "alt": img.get('alt', ''),
                "tag": "img"
            },
            "image_url": img_absolute_url
        })

    # Extract images from <source> in <picture> tags
    for source in soup.find_all('source'):
        if 'srcset' in source.attrs:
            img_url = source['srcset'].split(',')[0].strip()
            img_absolute_url = urljoin(base_url, img_url)
            results.append({
                "attributes": {"tag": "source"},
                "image_url": img_absolute_url
            })

    # Extract background images in inline styles
    for tag in soup.find_all(style=lambda value: value and "background-image" in value):
        style = tag.get('style')
        start = style.find("url(") + 4
        end = style.find(")", start)
        img_url = style[start:end].strip("'\"")
        img_absolute_url = urljoin(base_url, img_url)
        results.append({
            "attributes": {"tag": tag.name, "style": style},
            "image_url": img_absolute_url
        })

    return results

def final_image_extraction(url):
    """
    Extract images from a single URL based on the domain, using specific extraction methods
    for defined companies (e.g., Amazon, Shopsy).

    Args:
    - url (str): The webpage URL to scrape images from.

    Returns:
    - list of dict: Contains unique image attributes and URLs.
    """
    print(f"Processing URL: {url}\n")

    # Map of domain keywords to extraction functions
    domain_extractors = {
        "amazon": extract_images_with_retry,
        "shopsy": extract_images_from_webpage,
        # Add more companies and their corresponding functions here
        
    }

    # Identify the correct function based on the domain
    extraction_function = None
    for domain, extractor in domain_extractors.items():
        if domain in url:
            extraction_function = extractor
            print(f"Using `{extractor.__name__}` for {domain.capitalize()} URL.\n")
            break

    # If no matching domain found, return an empty list
    if not extraction_function:
        print("Domain not recognized for specific handling. Returning empty list.\n")
        return []

    # Extract images using the selected function
    images = extraction_function(url)

    # Remove duplicates
    unique_images = {img['image_url']: img for img in images}.values()

    # Convert to list and return
    return list(unique_images)


